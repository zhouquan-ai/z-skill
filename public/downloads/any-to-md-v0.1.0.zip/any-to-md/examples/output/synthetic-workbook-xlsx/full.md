# 测试数据

<table>
  <tr>
    <th colspan="4"><p>Any-to-MD 脱敏 Excel 样例</p></th>
  </tr>
</table>

<table>
  <tr>
    <th><p>项目</p></th>
    <th><p>数量</p></th>
    <th><p>单价</p></th>
    <th><p>金额</p></th>
  </tr>
  <tr>
    <td><p>仿真资料A</p></td>
    <td><p>2</p></td>
    <td><p>120</p></td>
    <td><p>240</p></td>
  </tr>
  <tr>
    <td><p>仿真资料B</p></td>
    <td><p>3</p></td>
    <td><p>80</p></td>
    <td><p>240</p></td>
  </tr>
  <tr>
    <td><p>合计</p></td>
    <td><p></p></td>
    <td><p></p></td>
    <td><p>480</p></td>
  </tr>
</table>

# 说明

<table>
  <tr>
    <th colspan="2"><p>样例说明</p></th>
  </tr>
</table>

<table>
  <tr>
    <th><p>字段</p></th>
    <th><p>内容</p></th>
  </tr>
  <tr>
    <td><p>用途</p></td>
    <td><p>验证 XLSX 转 Markdown 的表格、数字和公式结果</p></td>
  </tr>
  <tr>
    <td><p>隐私</p></td>
    <td><p>全部内容均为虚构</p></td>
  </tr>
  <tr>
    <td><p>边界</p></td>
    <td><p>Markdown不替代Excel公式和原始工作簿</p></td>
  </tr>
</table>