# 仿真资料转换验收说明

用于验证 DOCX、PDF 和图片转 Markdown，不含任何真实个人、客户或公司信息。

## 测试范围

转换后应保留标题层级、段落顺序、编号、日期、金额和表格对应关系。

## 验收步骤

1. 保留原文件

2. 执行格式转换

3. 运行本地质量扫描

4. 逐项对照源文件

## 仿真数据

<table><tr><td rowspan=1 colspan=1>资料类型</td><td rowspan=1 colspan=1>测试日期</td><td rowspan=1 colspan=1>状态</td></tr><tr><td rowspan=1 colspan=1>DOCX</td><td rowspan=1 colspan=1>2026-07-12</td><td rowspan=1 colspan=1>待转换</td></tr><tr><td rowspan=1 colspan=1>PDF</td><td rowspan=1 colspan=1>2026-07-12</td><td rowspan=1 colspan=1>待转换</td></tr><tr><td rowspan=1 colspan=1>PNG</td><td rowspan=1 colspan=1>2026-07-12</td><td rowspan=1 colspan=1>待转换</td></tr></table>

## 边界说明

注意：Markdown 是便于 AI 读取和人工维护的衍生资料，不替代原文件、签章、公式、批注和版式。