# 仿真资料转换验收

## 1 测试范围

## 1.1 修复目标

1. PDF 转换
1. Word 转换
1. Excel 转换

账户名：示例公司账号：123456开户行：示例银行

<table><tr><th>格式</th><th>状态</th></tr><tr><td>PDF</td><td>已验证</td></tr><tr><td>Markdown</td><td>A|B</td></tr></table>




以上内容全部为虚构测试数据。
