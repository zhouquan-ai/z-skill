# Known limitations

- MinerU conversion requires network access and sends the file to a third-party service.
- The token-free light API is limited to 10 MB and 20 pages, is rate-limited by IP, and returns Markdown only.
- OCR accuracy depends on image quality, language, layout, stamps, handwriting, and background noise.
- Markdown does not preserve legal evidentiary appearance, signatures, seals, tracked changes, comments, formulas, macros, slide animation, or exact page layout.
- Complex merged, nested, or borderless tables may require reconstruction against the source.
- The optimizer uses conservative patterns. It cannot infer missing clauses or repair content by meaning.
- DOCX is listed by MinerU's current API documentation and has worked in the author's prior use, but the v0.1 public sample failed twice through the token-free light API on 2026-07-12.
- PPT and PPTX are listed by MinerU's current API documentation, but v0.1 does not include a repository-owned PPT/PPTX acceptance sample.
- Legacy DOC and XLS files and less common image formats do not have repository-owned acceptance samples in v0.1.
- HTML files and webpage URLs are outside the bundled v0.1 workflow.
- API formats, quotas, limits, and response fields may change. Recheck MinerU's official documentation before a release.
