#!/usr/bin/env python3
"""Convert one supported local file with MinerU and preserve the result bundle."""

from __future__ import annotations

import argparse
import http.client
import json
import os
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

API_BASE = "https://mineru.net/api/v4"
AGENT_API_BASE = "https://mineru.net/api/v1/agent"
MAX_BYTES = 200 * 1024 * 1024
LIGHT_MAX_BYTES = 10 * 1024 * 1024
SUPPORTED_EXTENSIONS = {
    ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx",
    ".png", ".jpg", ".jpeg", ".jp2", ".webp", ".gif", ".bmp",
}
LIGHT_EXTENSIONS = {
    ".pdf", ".docx", ".pptx", ".xlsx",
    ".png", ".jpg", ".jpeg", ".jp2", ".webp", ".gif", ".bmp",
}
SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent


class ConversionError(RuntimeError):
    """A user-facing conversion failure."""


def _load_env_token(path: Path) -> str:
    if not path.is_file():
        return ""
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key.strip() == "MINERU_API_TOKEN":
            return value.strip().strip('"').strip("'")
    return ""


def get_token() -> str:
    return os.environ.get("MINERU_API_TOKEN", "").strip() or _load_env_token(
        SKILL_DIR / "config" / ".env"
    )


def _request_json(url: str, *, token: str = "", data: dict | None = None) -> tuple[int, dict]:
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = None
    method = "GET"
    if data is not None:
        headers["Content-Type"] = "application/json"
        body = json.dumps(data).encode("utf-8")
        method = "POST"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            payload = json.loads(response.read().decode("utf-8"))
            return response.status, payload
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise ConversionError(f"MinerU HTTP {exc.code}: {detail[:500]}") from exc
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise ConversionError(f"MinerU request failed: {exc}") from exc


def _api_data(response: dict, action: str) -> dict:
    code = response.get("code")
    if code not in (None, 0, "0"):
        message = response.get("msg") or response.get("message") or str(response)
        raise ConversionError(f"MinerU {action} failed ({code}): {message}")
    data = response.get("data")
    if not isinstance(data, dict):
        raise ConversionError(f"MinerU {action} returned no data object")
    return data


def _upload(url: str, input_path: Path) -> None:
    parsed = urllib.parse.urlparse(url)
    connection_class = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
    connection = connection_class(parsed.hostname, parsed.port, timeout=180)
    target = parsed.path + (f"?{parsed.query}" if parsed.query else "")
    try:
        data = input_path.read_bytes()
        connection.request("PUT", target, body=data, headers={"Content-Length": str(len(data))})
        response = connection.getresponse()
        detail = response.read().decode("utf-8", errors="replace")
        if response.status not in (200, 201):
            raise ConversionError(f"Upload failed with HTTP {response.status}: {detail[:300]}")
    except (OSError, TimeoutError, http.client.HTTPException) as exc:
        raise ConversionError(f"Upload failed: {exc}") from exc
    finally:
        connection.close()


def _safe_extract(zip_path: Path, destination: Path) -> None:
    destination = destination.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        for info in archive.infolist():
            posix_path = PurePosixPath(info.filename)
            if posix_path.is_absolute() or ".." in posix_path.parts:
                raise ConversionError(f"Unsafe archive member: {info.filename}")
            target = (destination / Path(*posix_path.parts)).resolve()
            if destination not in target.parents and target != destination:
                raise ConversionError(f"Unsafe archive member: {info.filename}")
        archive.extractall(destination)


def _prepare_output(output_root: Path, stem: str, overwrite: bool) -> Path:
    target = output_root / stem
    if target.exists() and any(target.iterdir()):
        if not overwrite:
            raise ConversionError(f"Output exists and is not empty: {target}")
        shutil.rmtree(target)
    target.mkdir(parents=True, exist_ok=True)
    return target


def convert(
    input_file: Path,
    output_root: Path,
    *,
    token: str,
    mode: str = "normal",
    language: str = "ch",
    overwrite: bool = False,
    poll_seconds: int = 5,
    max_wait_seconds: int = 600,
) -> dict:
    input_file = input_file.resolve()
    if not input_file.is_file():
        raise ConversionError(f"Input file not found: {input_file}")
    if input_file.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ConversionError(f"Unsupported extension: {input_file.suffix.lower() or '<none>'}")
    if input_file.stat().st_size == 0:
        raise ConversionError("Input file is empty")
    if input_file.stat().st_size > MAX_BYTES:
        raise ConversionError("Input file exceeds the 200 MiB public-script limit")
    if not token:
        raise ConversionError("MINERU_API_TOKEN is not configured")

    output_name = f"{input_file.stem}-{input_file.suffix.lstrip('.').lower()}"
    output_dir = _prepare_output(output_root.resolve(), output_name, overwrite)
    data_id = f"any_to_md_{int(time.time())}_{os.urandom(4).hex()}"
    payload = {
        "enable_formula": True,
        "enable_table": True,
        "language": language,
        "files": [{"name": input_file.name, "is_ocr": mode == "ocr", "data_id": data_id}],
    }

    _, response = _request_json(f"{API_BASE}/file-urls/batch", token=token, data=payload)
    data = _api_data(response, "upload request")
    batch_id = data.get("batch_id")
    urls = data.get("file_urls") or []
    if not batch_id or not urls:
        raise ConversionError("MinerU did not return a batch id and upload URL")

    _upload(str(urls[0]), input_file)
    deadline = time.monotonic() + max_wait_seconds
    result_url = ""
    last_state = "unknown"
    while time.monotonic() < deadline:
        time.sleep(poll_seconds)
        _, poll_response = _request_json(
            f"{API_BASE}/extract-results/batch/{batch_id}", token=token
        )
        poll_data = _api_data(poll_response, "result polling")
        results = poll_data.get("extract_result") or []
        if not results:
            continue
        current = results[0]
        last_state = str(current.get("state", "unknown"))
        if last_state == "failed":
            raise ConversionError(str(current.get("err_msg") or "MinerU processing failed"))
        if last_state == "done" and current.get("full_zip_url"):
            result_url = str(current["full_zip_url"])
            break
    if not result_url:
        raise ConversionError(f"MinerU timed out; last state: {last_state}")

    with tempfile.TemporaryDirectory(prefix="any_to_md_") as temp_dir:
        zip_path = Path(temp_dir) / "result.zip"
        try:
            urllib.request.urlretrieve(result_url, zip_path)
        except (urllib.error.URLError, OSError) as exc:
            raise ConversionError(f"Result download failed: {exc}") from exc
        _safe_extract(zip_path, output_dir)

    markdown_files = sorted(str(path.relative_to(output_dir)) for path in output_dir.rglob("*.md"))
    if not markdown_files:
        raise ConversionError("The result bundle contains no Markdown file")

    manifest = {
        "source_file": input_file.name,
        "source_size_bytes": input_file.stat().st_size,
        "engine": "MinerU API v4 file-urls/batch",
        "mode": mode,
        "language": language,
        "converted_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "markdown_files": markdown_files,
        "source_retained": True,
        "review_required": True,
    }
    (output_dir / "conversion-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return {"output_dir": str(output_dir), **manifest}


def convert_light(
    input_file: Path,
    output_root: Path,
    *,
    mode: str = "normal",
    language: str = "ch",
    overwrite: bool = False,
    poll_seconds: int = 3,
    max_wait_seconds: int = 300,
) -> dict:
    """Use MinerU's token-free Agent API for small public or low-risk files."""
    input_file = input_file.resolve()
    if not input_file.is_file():
        raise ConversionError(f"Input file not found: {input_file}")
    if input_file.suffix.lower() not in LIGHT_EXTENSIONS:
        raise ConversionError(f"Light API does not support: {input_file.suffix.lower() or '<none>'}")
    if input_file.stat().st_size == 0:
        raise ConversionError("Input file is empty")
    if input_file.stat().st_size > LIGHT_MAX_BYTES:
        raise ConversionError("Light API input exceeds 10 MiB")

    output_name = f"{input_file.stem}-{input_file.suffix.lstrip('.').lower()}"
    output_dir = _prepare_output(output_root.resolve(), output_name, overwrite)
    payload = {
        "file_name": input_file.name,
        "language": language,
        "enable_table": True,
        "is_ocr": mode == "ocr",
        "enable_formula": True,
    }
    _, response = _request_json(f"{AGENT_API_BASE}/parse/file", data=payload)
    data = _api_data(response, "light upload request")
    task_id = data.get("task_id")
    upload_url = data.get("file_url")
    if not task_id or not upload_url:
        raise ConversionError("Light API did not return a task id and upload URL")
    _upload(str(upload_url), input_file)

    deadline = time.monotonic() + max_wait_seconds
    markdown_url = ""
    last_state = "unknown"
    while time.monotonic() < deadline:
        time.sleep(poll_seconds)
        _, poll_response = _request_json(f"{AGENT_API_BASE}/parse/{task_id}")
        poll_data = _api_data(poll_response, "light result polling")
        last_state = str(poll_data.get("state", "unknown"))
        if last_state == "failed":
            detail = (
                poll_data.get("err_msg")
                or poll_data.get("error")
                or poll_data.get("message")
                or poll_data.get("msg")
                or json.dumps(poll_data, ensure_ascii=False)
            )
            raise ConversionError(f"Light parsing failed: {detail}")
        if last_state == "done" and poll_data.get("markdown_url"):
            markdown_url = str(poll_data["markdown_url"])
            break
    if not markdown_url:
        raise ConversionError(f"Light API timed out; last state: {last_state}")

    markdown_path = output_dir / "full.md"
    try:
        urllib.request.urlretrieve(markdown_url, markdown_path)
    except (urllib.error.URLError, OSError) as exc:
        raise ConversionError(f"Markdown download failed: {exc}") from exc

    manifest = {
        "source_file": input_file.name,
        "source_size_bytes": input_file.stat().st_size,
        "engine": "MinerU Agent light API v1",
        "mode": mode,
        "language": language,
        "converted_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "markdown_files": ["full.md"],
        "source_retained": True,
        "review_required": True,
        "light_api_limits": {"max_bytes": LIGHT_MAX_BYTES, "max_pages": 20},
    }
    (output_dir / "conversion-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return {"output_dir": str(output_dir), **manifest}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_file", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=("normal", "ocr"), default="normal")
    parser.add_argument("--api-mode", choices=("auto", "precise", "light"), default="auto")
    parser.add_argument("--language", default="ch")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--poll-seconds", type=int, default=5)
    parser.add_argument("--max-wait-seconds", type=int, default=600)
    args = parser.parse_args()
    try:
        token = get_token()
        api_mode = args.api_mode
        if api_mode == "auto":
            api_mode = "precise" if token else "light"
        common = {
            "mode": args.mode,
            "language": args.language,
            "overwrite": args.overwrite,
            "poll_seconds": max(1, args.poll_seconds),
            "max_wait_seconds": max(10, args.max_wait_seconds),
        }
        if api_mode == "precise":
            result = convert(args.input_file, args.output_dir, token=token, **common)
        else:
            result = convert_light(args.input_file, args.output_dir, **common)
    except ConversionError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
