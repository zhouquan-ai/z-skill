#!/usr/bin/env python3
"""Apply conservative, deterministic repairs to a Markdown file."""

from __future__ import annotations

import argparse
import html
import re
from html.parser import HTMLParser
from pathlib import Path


class _TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell: list[str] | None = None

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag.lower() == "tr":
            self._row = []
        elif tag.lower() in {"td", "th"} and self._row is not None:
            self._cell = []
        elif tag.lower() == "br" and self._cell is not None:
            self._cell.append("<br>")

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            self._cell.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in {"td", "th"} and self._cell is not None and self._row is not None:
            value = " ".join("".join(self._cell).split()).replace("|", r"\|")
            self._row.append(value)
            self._cell = None
        elif tag.lower() == "tr" and self._row is not None:
            if self._row:
                self.rows.append(self._row)
            self._row = None


def _outside_code_blocks(text: str, transform) -> str:
    parts = re.split(r"(```[\s\S]*?```)", text)
    return "".join(part if part.startswith("```") else transform(part) for part in parts)


def fix_whitespace(text: str) -> tuple[str, int]:
    original = text
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = "\n".join(line.rstrip() for line in text.split("\n"))
    text = re.sub(r"\n{4,}", "\n\n\n", text).strip("\n") + "\n"
    return text, int(text != original)


def fix_subsection_headings(text: str) -> tuple[str, int]:
    lines = text.splitlines()
    parent_numbers = {
        match.group(1)
        for line in lines
        if (match := re.match(r"^##\s+(\d+)\s+", line.strip()))
    }
    count = 0
    result: list[str] = []
    for line in lines:
        match = re.match(r"^(\s*)##\s+(\d+)\.(\d+)\s+(.+)$", line)
        if match and match.group(2) in parent_numbers:
            line = f"{match.group(1)}### {match.group(2)}.{match.group(3)} {match.group(4)}"
            count += 1
        result.append(line)
    return "\n".join(result), count


def fix_repeated_one_lists(text: str) -> tuple[str, int]:
    lines = text.splitlines()
    count = 0
    run_start = 0
    while run_start < len(lines):
        if not re.match(r"^\s*1\.\s+", lines[run_start]):
            run_start += 1
            continue
        run_end = run_start
        while run_end < len(lines) and re.match(r"^\s*1\.\s+", lines[run_end]):
            run_end += 1
        if run_end - run_start >= 2:
            for index, line_index in enumerate(range(run_start, run_end), 1):
                if index > 1:
                    lines[line_index] = re.sub(r"^(\s*)1\.\s+", rf"\g<1>{index}. ", lines[line_index])
                    count += 1
        run_start = run_end
    return "\n".join(lines), count


def fix_number_spacing(text: str) -> tuple[str, int]:
    def transform(part: str) -> str:
        part = re.sub(r"(\d+)\s*[．]\s*(\d+)", r"\1.\2", part)
        part = re.sub(r"^([ \t]*)(\d+)\s*、\s*", r"\1\2. ", part, flags=re.MULTILINE)
        part = re.sub(r"^([ \t]*\d+)\.(?=[^\d\s])", r"\1. ", part, flags=re.MULTILINE)
        part = re.sub(r"（\s*(\d+)\s*）", r"（\1）", part)
        part = re.sub(r"\(\s*(\d+)\s*\)", r"(\1)", part)
        return part

    fixed = _outside_code_blocks(text, transform)
    return fixed, int(fixed != text)


def fix_account_fields(text: str) -> tuple[str, int]:
    patterns = [
        (
            re.compile(r"账户名[：:]\s*(.*?)\s*(?:账号|账\s*号)[：:]\s*(.*?)\s*开户行[：:]\s*([^\n]+)"),
            lambda m: f"账户名：{m.group(1).strip()}\n账号：{m.group(2).strip()}\n开户行：{m.group(3).strip()}",
        ),
        (
            re.compile(r"开户行[：:]\s*(.*?)\s*账户名(?:称)?[：:]\s*(.*?)\s*(?:银行)?账号[：:]\s*([^\n]+)"),
            lambda m: f"开户行：{m.group(1).strip()}\n账户名称：{m.group(2).strip()}\n银行账号：{m.group(3).strip()}",
        ),
    ]
    count = 0
    for pattern, replacement in patterns:
        text, changed = pattern.subn(replacement, text)
        count += changed
    return text, count


def _html_table_to_gfm(table_html: str) -> str:
    parser = _TableParser()
    parser.feed(table_html)
    if not parser.rows:
        return table_html
    width = max(len(row) for row in parser.rows)
    rows = [row + [""] * (width - len(row)) for row in parser.rows]
    rendered = ["| " + " | ".join(rows[0]) + " |"]
    rendered.append("| " + " | ".join(["---"] * width) + " |")
    rendered.extend("| " + " | ".join(row) + " |" for row in rows[1:])
    return "\n".join(rendered)


def fix_html_tables(text: str) -> tuple[str, int]:
    pattern = re.compile(r"<table\b[^>]*>[\s\S]*?</table>", re.IGNORECASE)
    count = 0

    def replace(match: re.Match) -> str:
        nonlocal count
        converted = _html_table_to_gfm(html.unescape(match.group(0)))
        if converted != match.group(0):
            count += 1
        return converted

    return pattern.sub(replace, text), count


def fix_table_separators(text: str) -> tuple[str, int]:
    lines = text.splitlines()
    count = 0
    index = 0
    while index + 1 < len(lines):
        header = lines[index].strip()
        next_line = lines[index + 1].strip()
        previous = lines[index - 1].strip() if index else ""
        is_table_start = not (previous.startswith("|") and previous.endswith("|"))
        if is_table_start and header.startswith("|") and header.endswith("|") and header.count("|") >= 2:
            is_separator = bool(re.fullmatch(r"[|:\-\s]+", next_line))
            if not is_separator and next_line.startswith("|"):
                columns = max(1, header.count("|") - 1)
                lines.insert(index + 1, "| " + " | ".join(["---"] * columns) + " |")
                count += 1
                index += 1
        index += 1
    return "\n".join(lines), count


def optimize(text: str) -> tuple[str, list[str]]:
    changes: list[str] = []
    operations = [
        ("normalize whitespace", fix_whitespace),
        ("normalize numbering", fix_number_spacing),
        ("repair subsection headings", fix_subsection_headings),
        ("repair repeated numbered lists", fix_repeated_one_lists),
        ("split concatenated account fields", fix_account_fields),
        ("convert simple HTML tables", fix_html_tables),
        ("add missing table separators", fix_table_separators),
    ]
    for label, operation in operations:
        text, count = operation(text)
        if count:
            changes.append(f"{label}: {count}")
    if not text.endswith("\n"):
        text += "\n"
    return text, changes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("markdown_file", type=Path)
    parser.add_argument("--check", action="store_true", help="Report changes without writing")
    args = parser.parse_args()
    original = args.markdown_file.read_text(encoding="utf-8")
    fixed, changes = optimize(original)
    if not args.check and fixed != original:
        args.markdown_file.write_text(fixed, encoding="utf-8")
    for change in changes:
        print(change)
    return 1 if args.check and fixed != original else 0


if __name__ == "__main__":
    raise SystemExit(main())
