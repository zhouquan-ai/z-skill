#!/usr/bin/env python3
"""Scan Markdown files for structural defects that need review."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def _issue(kind: str, detail: str, line: int = 0) -> dict:
    return {"type": kind, "detail": detail, "line": line}


def scan_text(text: str, base_dir: Path | None = None) -> list[dict]:
    lines = text.splitlines()
    issues: list[dict] = []
    if not text.strip():
        return [_issue("empty", "File contains no text")]
    first_content = next((line.strip() for line in lines if line.strip()), "")
    if not first_content.startswith("# "):
        issues.append(_issue("missing_h1", "First content line is not an H1 heading"))
    if re.search(r"<table\b|</?(?:tr|td|th)\b", text, re.IGNORECASE):
        issues.append(_issue("html_table", "HTML table markup remains"))
    if re.search(r"\n{4,}", text):
        issues.append(_issue("excess_blank_lines", "More than two blank lines remain"))

    prior_heading = 0
    consecutive_ones = 0
    for number, line in enumerate(lines, 1):
        if line.rstrip() != line:
            issues.append(_issue("trailing_whitespace", "Trailing whitespace", number))
        heading = re.match(r"^(#{1,6})\s+", line)
        if heading:
            level = len(heading.group(1))
            if prior_heading and level > prior_heading + 1:
                issues.append(_issue("heading_jump", f"Heading jumps from H{prior_heading} to H{level}", number))
            prior_heading = level
        if re.match(r"^\s*1\.\s+", line):
            consecutive_ones += 1
            if consecutive_ones == 2:
                issues.append(_issue("repeated_one_list", "Consecutive list items start with 1.", number))
        else:
            consecutive_ones = 0
        if re.match(r"^\s*\d+\.[^\d\s]", line):
            issues.append(_issue("list_spacing", "Numbered list marker has no following space", number))
        if re.search(r"账户名[：:].*(?:账号|账\s*号)[：:].*开户行[：:]", line):
            issues.append(_issue("account_concat", "Account fields remain concatenated", number))

    for index, line in enumerate(lines):
        stripped = line.strip()
        if not (stripped.startswith("|") and stripped.endswith("|") and stripped.count("|") >= 2):
            continue
        previous = lines[index - 1].strip() if index else ""
        if previous.startswith("|") and previous.endswith("|"):
            continue
        if index + 1 >= len(lines) or not re.fullmatch(r"[|:\-\s]+", lines[index + 1].strip()):
            issues.append(_issue("table_separator", "Table header has no separator row", index + 1))

    for match in re.finditer(r"!\[[^\]]*\]\(([^)]+)\)", text):
        target = match.group(1).strip()
        if re.match(r"https?://", target) or not base_dir:
            continue
        if not (base_dir / target).exists():
            line = text[: match.start()].count("\n") + 1
            issues.append(_issue("missing_image", f"Referenced image does not exist: {target}", line))
    return issues


def scan_path(path: Path) -> dict:
    files = [path] if path.is_file() else sorted(path.rglob("*.md"))
    report = {"total": len(files), "clean": 0, "with_issues": 0, "files": {}}
    for file_path in files:
        issues = scan_text(file_path.read_text(encoding="utf-8"), file_path.parent)
        key = str(file_path if path.is_file() else file_path.relative_to(path))
        if issues:
            report["with_issues"] += 1
            report["files"][key] = issues
        else:
            report["clean"] += 1
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path)
    parser.add_argument("--json", dest="json_path", type=Path)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    report = scan_path(args.path)
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    print(rendered)
    if args.json_path:
        args.json_path.write_text(rendered + "\n", encoding="utf-8")
    return 1 if args.strict and report["with_issues"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
