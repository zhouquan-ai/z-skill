# Format routing and verification status

## Meaning of status

- `Repository verified`: the public package includes a synthetic input and a recorded end-to-end result.
- `Author experience`: the author has converted this kind of file in personal work, but the public package does not preserve a format-specific historical report.
- `API supported, repository unverified`: MinerU's current official API documentation lists the format, but this repository has not completed its own sample conversion.

## Routing table

| Input | Route | Public-package status on 2026-07-12 |
|---|---|---|
| PDF with text | MinerU normal mode | Repository verified through the token-free light API |
| Scanned PDF | MinerU OCR mode | Author experience only; no scanned-PDF public sample |
| DOCX | MinerU normal mode | Author experience; public sample failed twice in the token-free light API |
| DOC | MinerU normal mode | Author experience only; no public sample |
| XLSX | MinerU normal mode | Repository verified through the token-free light API |
| XLS | MinerU normal mode | Author experience only; no public sample |
| PNG | MinerU normal mode | Repository verified through the token-free light API |
| JPG/JPEG | MinerU normal mode | API supported, repository unverified |
| PPT/PPTX | MinerU normal mode | API supported, repository unverified |
| JP2/WEBP/GIF/BMP | MinerU normal mode | API supported, repository unverified |
| Markdown | Local optimizer and QA | Repository verified with the bundled repair fixture and unit tests |
| HTML or webpage URL | Outside v0.1 bundled workflow | Do not claim bundled support |

The preserved commands, output paths, dates, and acceptance results are recorded in `TEST_MATRIX.md` and `examples/results/acceptance-2026-07-12.md` at the public-package root.

## Source preservation

Markdown is a derivative reading layer. Retain the original whenever it contains formulas, comments, tracked changes, signatures, seals, page layout, images, charts, slide composition, or other information that may affect meaning or proof.
