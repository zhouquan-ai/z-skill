---
name: any-to-md
description: Convert PDF, Word, Excel, PowerPoint, and image files into reviewable Markdown through MinerU, then repair and inspect Markdown structure. Use when the user asks to convert files to Markdown, run OCR, clean malformed Markdown, preserve document assets, or assess conversion quality. Always retain the source file and disclose that MinerU conversion uploads the file to a third-party service.
---

# Any to Markdown

Turn source files into AI-readable derivative material. Never treat Markdown as a substitute for the source file, signed original, spreadsheet formulas, tracked changes, or evidentiary appearance.

## Route the input

1. Identify the extension and whether the input contains confidential, personal, client, case, employment, or company information.
2. For an existing `.md` file, skip remote conversion and run the local repair and QA scripts.
3. For PDF, Word, Excel, PowerPoint, or supported images, use MinerU only after the user understands that the file will leave the local environment.
4. For URLs, encrypted files, unsupported formats, or files that cannot be uploaded, use another available reader or ask for pasted text. Do not claim this skill converted them.

Read [format-routing.md](references/format-routing.md) before converting a format that is marked unverified.

## Protect the source

- Keep the original file unchanged.
- Write results to a separate output directory.
- Do not include tokens in commands, logs, reports, archives, or Markdown.
- Do not upload sensitive material unless the user has authority to use the external service.
- Record the source filename, conversion time, engine, mode, and unresolved defects next to the output.

## Convert with MinerU

For small, non-sensitive files, MinerU's token-free light API can be used with `--api-mode light`. It is limited to 10 MB and 20 pages and returns Markdown only. For the precise API, set `MINERU_API_TOKEN` in the environment or copy `config/.env.example` to `config/.env` and fill it locally. Never publish `config/.env`.

```bash
python scripts/mineru_convert.py "input.pdf" --output-dir "output"
python scripts/mineru_convert.py "scan.pdf" --output-dir "output" --mode ocr
python scripts/mineru_convert.py "public-sample.docx" --output-dir "output" --api-mode light
```

The precise converter preserves the returned Markdown and related assets inside a source-named directory. The light API saves the returned Markdown only. Both refuse to overwrite an existing non-empty result unless `--overwrite` is supplied.

Use OCR mode for scanned PDFs. Image inputs are inherently image-parsing tasks. Do not describe extension routing as automatic scan detection.

## Repair Markdown

Run deterministic repairs on a copy or a newly converted output:

```bash
python scripts/optimize_md.py "output/document.md"
```

The optimizer handles conservative structural defects such as trailing whitespace, excessive blank lines, repeated `1.` lists, common full-width numbering, simple HTML tables, missing Markdown table separators, numbered subsection levels, and concatenated account fields.

It does not reconstruct merged tables, infer missing clauses, restore signatures, recreate slide composition, or verify factual accuracy.

## Inspect the result

```bash
python scripts/qa_md.py "output/document.md"
python scripts/qa_md.py "output" --json "qa-report.json"
```

Then compare the result with the source. Check at least:

- title and heading hierarchy;
- paragraph and list order;
- table row and column correspondence;
- numbers, dates, names, amounts, and clause references;
- image links and accompanying asset files;
- OCR errors, page numbers, headers, footers, and system marks;
- truncated endings and missing attachments.

If the source contains legal, financial, medical, employment, or other consequential information, require human review before downstream use.

## Report completion honestly

State:

- what engine and mode were used;
- which files were produced;
- whether local QA passed;
- what still requires comparison with the source;
- which source features Markdown does not preserve.

Do not say “perfect conversion,” “lossless,” or “all formats supported.”
