from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "skill" / "any-to-md" / "scripts"


def load_module(name: str):
    spec = importlib.util.spec_from_file_location(name, SCRIPTS / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


optimize_md = load_module("optimize_md")
qa_md = load_module("qa_md")
mineru_convert = load_module("mineru_convert")


class OptimizerTests(unittest.TestCase):
    def test_public_fixture_matches_expected(self):
        source = (ROOT / "examples" / "input" / "markdown-repair.md").read_text(encoding="utf-8")
        expected = (ROOT / "examples" / "expected" / "markdown-repair.md").read_text(encoding="utf-8")
        fixed, changes = optimize_md.optimize(source)
        self.assertEqual(expected, fixed)
        self.assertGreaterEqual(len(changes), 4)

    def test_full_width_decimal(self):
        fixed, _ = optimize_md.optimize("# 标题\n\n2 ．1 服务内容\n")
        self.assertIn("2.1 服务内容", fixed)

    def test_numbered_list_spacing(self):
        fixed, _ = optimize_md.optimize("# 标题\n\n1.保留原文件\n")
        self.assertIn("1. 保留原文件", fixed)

    def test_code_block_is_unchanged(self):
        source = "# 标题   \n\n```text\n2 ．1\n```\n"
        fixed, changes = optimize_md.optimize(source)
        self.assertTrue(fixed.startswith("# 标题\n"))
        self.assertIn("```text\n2 ．1\n```", fixed)
        self.assertTrue(any(change.startswith("normalize whitespace") for change in changes))


class QATests(unittest.TestCase):
    def test_clean_expected_fixture(self):
        path = ROOT / "examples" / "expected" / "markdown-repair.md"
        issues = qa_md.scan_text(path.read_text(encoding="utf-8"), path.parent)
        self.assertEqual([], issues)

    def test_missing_image(self):
        with tempfile.TemporaryDirectory() as temp:
            issues = qa_md.scan_text("# Title\n\n![x](missing.png)\n", Path(temp))
        self.assertTrue(any(issue["type"] == "missing_image" for issue in issues))

    def test_english_heading_jump_is_detected(self):
        issues = qa_md.scan_text("# Contract\n\n### Payment\n")
        self.assertTrue(any(issue["type"] == "heading_jump" for issue in issues))


class ConverterValidationTests(unittest.TestCase):
    def test_official_extensions_are_routed(self):
        for extension in (".pdf", ".docx", ".xlsx", ".pptx", ".png", ".webp"):
            self.assertIn(extension, mineru_convert.SUPPORTED_EXTENSIONS)

    def test_zip_path_traversal_is_rejected(self):
        import zipfile

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = root / "unsafe.zip"
            with zipfile.ZipFile(archive, "w") as handle:
                handle.writestr("../escape.md", "bad")
            with self.assertRaises(mineru_convert.ConversionError):
                mineru_convert._safe_extract(archive, root / "out")


if __name__ == "__main__":
    unittest.main()
