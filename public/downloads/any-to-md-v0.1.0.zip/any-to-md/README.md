# Any to Markdown

Any-to-MD把常见文件转换成便于 AI读取、全文检索、人工维护和跨平台迁移的 Markdown衍生资料，并提供本地格式修复和质量扫描。

它不替代原文件。涉及公式、批注、修订记录、签章、版式、图片、幻灯片视觉关系或法律证据原貌时，必须保留并回看原件。

## 当前状态

当前正式版本为 `v0.1.0`。代码作者为周全，以 MIT 许可证发布。Codex 实际触发已于 2026-07-13 通过。

当前官方 MinerU API列明支持 PDF、Word、Excel、PowerPoint和多种图片格式。本仓库只把保存了仿真输入、执行命令、输出和验收结果的格式标为“本仓库已验证”。详见 [TEST_MATRIX.md](TEST_MATRIX.md)。

## 仓库结构

```text
any-to-md/
├─ README.md
├─ LICENSE
├─ PRIVACY.md
├─ KNOWN_LIMITATIONS.md
├─ THIRD_PARTY_NOTICES.md
├─ TEST_MATRIX.md
├─ skill/any-to-md/
├─ examples/
└─ tests/
```

`skill/any-to-md/`是可放入 Agent Skills 目录的 Skill 本体；仓库根目录保存面向使用者的说明、测试和许可证。

## 安装

在 Codex 中，把 `skill/any-to-md` 复制到 `~/.codex/skills/any-to-md`，重新加载后即可使用。其他 Agent 可将同一目录放入其 Skills 目录。

MinerU Token建议通过环境变量配置：

```bash
export MINERU_API_TOKEN="your-token"
```

Windows PowerShell：

```powershell
$env:MINERU_API_TOKEN="your-token"
```

也可以把 `skill/any-to-md/config/.env.example`复制为同目录下的 `.env`后填写。`.env`已被仓库忽略，不得提交或分享。

对不超过10MB、20页的非敏感小文件，也可以使用 MinerU免登录轻量接口，不需要 Token。轻量接口只返回 Markdown，适合试用和公开样例；高精度接口保留更完整的结构化结果包。

## 使用

### 转换文件

```bash
python skill/any-to-md/scripts/mineru_convert.py "input.pdf" --output-dir "output"
python skill/any-to-md/scripts/mineru_convert.py "scan.pdf" --output-dir "output" --mode ocr
python skill/any-to-md/scripts/mineru_convert.py "public-sample.pdf" --output-dir "output" --api-mode light
```

每个源文件会得到独立输出目录。高精度模式保存 MinerU返回的完整结果包；轻量模式保存返回的 Markdown。两种模式都会生成 `conversion-manifest.json`，记录源文件名、引擎、转换模式、时间和 Markdown文件列表。

### 修复Markdown

```bash
python skill/any-to-md/scripts/optimize_md.py "output/example.md"
```

### 扫描质量问题

```bash
python skill/any-to-md/scripts/qa_md.py "output/example.md"
python skill/any-to-md/scripts/qa_md.py "output" --json "qa-report.json"
```

质量扫描只能发现预先定义的结构问题。对法律、财务、医疗、人事等重要内容，仍须逐项对照原件。

## 隐私提醒

默认转换路径会把文件上传到 MinerU，不是纯本地处理。上传客户材料、案件文件、公司内部资料和个人信息前，请先确认权限及所在组织的保密要求。完整边界见 [PRIVACY.md](PRIVACY.md)。

## 获取方式

正式版可从以下两个入口获取：

- z-skill 详情页，用于查看版本、测试、隐私、限制和下载地址；
- GitHub 仓库，用于保存版本、许可证和精确技术差异。
