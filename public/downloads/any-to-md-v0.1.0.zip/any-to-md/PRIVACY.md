# Privacy and confidentiality

Any-to-MD keeps its scripts and final Markdown locally, but the default document conversion route is not fully local. Files processed through `mineru_convert.py` are uploaded to the MinerU service.

Before conversion, confirm that you are authorized to send the source file to an external service. Do not upload client secrets, case files, unpublished company materials, personal information, health records, financial records, credentials, or other restricted content merely because the script can process the format.

The repository must never contain:

- `config/.env`;
- a real API token;
- source files taken from personal or company work;
- conversion results containing real names, identifiers, contacts, signatures, seals, or account information.

Use only `config/.env.example` for distribution. Prefer the `MINERU_API_TOKEN` environment variable on shared machines.

The source file remains the authoritative artifact. Markdown may omit or alter layout, formulas, comments, signatures, images, tables, and other context. Review consequential content against the source before using it.
