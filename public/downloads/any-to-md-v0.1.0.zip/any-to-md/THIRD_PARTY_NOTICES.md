# Third-party notices

## MinerU

The bundled converter calls the MinerU document parsing API. MinerU is a third-party service and is not included in this repository. Users must obtain their own token where required and comply with MinerU's current service terms, limits, and privacy rules.

- API documentation: https://mineru.net/apiManage/docs
- Open-source project documentation: https://opendatalab.github.io/MinerU/

The MIT license in this repository applies only to the code and documentation authored by 周全. It does not license MinerU, Microsoft Office formats, or any external source document.
